# HRYAH · 2.5D Asset & Animation Workshop (`tools/asset-workshop`)

Standalone interactive 2.5D/3D GLB asset workshop, repeatable procedural generator, clean-scene validator, and React/Three.js import adapter for the **hryah** space mission game.

> **Reference Notice**: The private tailnet reference link (`https://pi4.tail777b15.ts.net/experimental/`) was not accessed. All models, module IDs, sockets, clips, and orbital switch state semantics are built directly from the repository sources (`docs/ASSET_WORKSHOP_TASK.md`, `docs/ORBIT_TASK.md`, `docs/ARCHITECTURE.md`, `src/core/contracts.ts`, `src/data/catalog.json`, `src/core/orbit/`, and `src/ui/orbit/`).

---

## 1. Quick Start & Commands

All dependencies for the workshop are isolated inside `tools/asset-workshop/package.json` so `package.json` of the main game remains untouched.

```bash
# 1. Install workshop dependencies (only needed once)
npm --prefix tools/asset-workshop install

# 2. Generate all 25 GLBs + manifest.json + hryah-workshop-pack.zip into public/assets/workshop/
npm --prefix tools/asset-workshop run generate

# 3. Validate all exported GLBs & ZIP by re-importing into a clean GLTFLoader scene
npm --prefix tools/asset-workshop run validate

# 4. Run unit & integration tests (GLB re-import, animations, orbital switch state machine, crew choreography)
npm --prefix tools/asset-workshop test

# 5. Launch the interactive 2.5D/3D HTML Asset Workshop viewer (http://localhost:5179)
npm --prefix tools/asset-workshop run dev

# 6. Build static production bundle of the workshop (tools/asset-workshop/dist/)
npm --prefix tools/asset-workshop run build
```

> **Note on HTTP vs `file://`**: Browser ES modules and `fetch()` for `.glb` binaries require an HTTP server (`npm --prefix tools/asset-workshop run dev` or `npm --prefix tools/asset-workshop run preview`). At the same time, the viewer also includes the full procedural generator in-browser, so every model, animation, and download button (`Download .glb`, `Download manifest.json`, `Download Complete ZIP`) works self-sufficiently without any external backend or CDN.

---

## 2. Coordinate System, Units & Renderer Conversion

- **Units**: `1 unit = 1 meter` (SI meters)
- **Up Axis**: `+Y`
- **Forward Axis**: `+Z`
- **Handedness**: Right-handed (standard glTF 2.0 binary `.glb`)
- **Materials**: Embedded `MeshStandardMaterial` (PBR `baseColorFactor`, `metallicFactor`, `roughnessFactor`, `emissiveFactor`). No external image paths or CDN URLs.
- **Conversion for other renderers**:
  - **Three.js / React Three Fiber**: Native match (`+Y` up, `+Z` forward, meters). Load directly with `GLTFLoader`.
  - **Babylon.js**: Set `scene.useRightHandedSystem = true` for 1:1 socket alignment, or let Babylon's glTF loader insert its default `__root__` Z-inversion node.
  - **Blender / Z-Up Engines**: Standard glTF 2.0 importers convert `+Y` up to `+Z` up automatically (`+90°` around `X`).

---

## 3. Exported Asset Catalog (`public/assets/workshop/`)

| Asset ID | File Path (`public/assets/workshop/`) | Category | Clips Baked in GLB | Stationary Sockets / Mounts |
|---|---|---|---|---|
| `astronaut` | `astronaut.glb` | Character (Phase 2) | `idle`, `run`, `float_idle`, `float_move`, `push_off`, `grab_handle`, `task_work`, `switch_on`, `switch_off`, `turn_left`, `turn_right`, `reposition`, `task_success`, `task_error` (14 clips) | `hand_target`, `hand_target_l`, `hand_target_r`, `backpack_mount` |
| `ship-cutaway` | `ship-cutaway.glb` | Ship Hull (Phase 2) | `hatch_open`, `hatch_close`, `docking_approach`, `docking_align`, `docking_latch`, `docking_docked`, `docking_abort`, `satellite_release_latch`, `satellite_depart`, `satellite_drift` (10 clips) | `satellite_release`, `console_interact`, `hand_target`, `mount_console_power`, `mount_console_thermal`, `mount_console_oxygen`, `mount_console_docking`, `mount_console_separation`, `anchor_*` |
| `console-power` | `consoles/console-power.glb` | Console (Phase 2) | `idle`, `switch_on`, `switch_off`, `work_cycle`, `confirm`, `alarm` | `console_interact`, `hand_target` |
| `console-thermal` | `consoles/console-thermal.glb` | Console (Phase 2) | `idle`, `switch_on`, `switch_off`, `work_cycle`, `confirm`, `alarm` | `console_interact`, `hand_target` |
| `console-oxygen` | `consoles/console-oxygen.glb` | Console (Phase 2) | `idle`, `switch_on`, `switch_off`, `work_cycle`, `confirm`, `alarm` | `console_interact`, `hand_target` |
| `console-docking` | `consoles/console-docking.glb` | Console (Phase 2) | `idle`, `switch_on`, `switch_off`, `work_cycle`, `confirm`, `alarm` | `console_interact`, `hand_target` |
| `console-separation` | `consoles/console-separation.glb` | Console (Phase 2) | `idle`, `switch_on`, `switch_off`, `work_cycle`, `confirm`, `alarm` | `console_interact`, `hand_target` |
| `satellite-bus` | `satellite-bus.glb` | Satellite (Phase 3) | `idle`, `safe_enter`, `safe_hold`, `safe_exit`, `heater_on`, `heater_off`, `separation_drift` | `solar_left`, `solar_right`, `antenna_mount`, `camera_mount`, `engine_mount`, `battery_mount`, `satellite_release` |
| `orbital-switches` | `consoles/orbital-switches.glb` | Orbital Panel (Phase 3) | `all_on_nominal`, `camera_on`, `camera_off`, `transmitter_on`, `transmitter_off`, `heater_on`, `heater_off`, `safe_mode_on`, `safe_mode_off` | `console_interact`, `hand_target` |
| `eng-cold` | `modules/eng-cold.glb` | Engine (`catalog.json`) | `idle`, `ignition`, `thrust`, `shutdown` | `engine_mount` |
| `eng-chem` | `modules/eng-chem.glb` | Engine (`catalog.json`) | `idle`, `ignition`, `thrust`, `shutdown` | `engine_mount` |
| `eng-ion` | `modules/eng-ion.glb` | Engine (`catalog.json`) | `idle`, `ignition`, `thrust`, `shutdown` | `engine_mount` |
| `sol-s`, `sol-m`, `sol-l` | `modules/sol-{s,m,l}.glb` | Solar (`catalog.json`) | `deploy`, `track_angle`, `hold`, `stow`, `safe_feather` | `solar_left`, `solar_right` |
| `bat-s`, `bat-m`, `bat-l` | `modules/bat-{s,m,l}.glb` | Battery (`catalog.json`) | `idle`, `charge_pulse`, `discharge_pulse`, `low_charge_warning` | `battery_mount` |
| `ant-s`, `ant-m`, `ant-l` | `modules/ant-{s,m,l}.glb` | Antenna (`catalog.json`) | `deploy`, `aim`, `transmit`, `standby`, `stow` | `antenna_mount` |
| `cam-s`, `cam-m`, `cam-l` | `modules/cam-{s,m,l}.glb` | Instrument (`catalog.json`) | `aim`, `scan`, `park`, `cold_locked` | `camera_mount` |
| `earth` | `environment/earth.glb` | Environment | `rotate_orbit`, `station_pass_ping`, `storm_front` | `ground_station_anchor` |

---

## 4. Optional VFX Layers vs Mechanical Models

Every visual effect is stored as a separate named child node (`vfx_scan_cone`, `vfx_downlink_beam`, `vfx_thruster_plume`, `vfx_heater_glow`, `vfx_cold_frost`, `vfx_storm_particles`) so that hiding or disabling effects leaves the mechanical 3D model 100% intact:

```ts
import { loadWorkshopGlb, attachModuleToSocket, WorkshopAnimationController } from './src/adapter/import-and-animate';

const busGltf = await loadWorkshopGlb('/assets/workshop/satellite-bus.glb');
const camGltf = await loadWorkshopGlb('/assets/workshop/modules/cam-m.glb');

attachModuleToSocket(busGltf.scene, 'camera_mount', camGltf.scene);

const camCtrl = new WorkshopAnimationController(camGltf.scene, camGltf.animations);
camCtrl.playClip('scan', { loop: true, crossFadeDurationS: 0.25 });
// Toggle scan frustum VFX independently of mechanical shutter/gimbal animation:
camCtrl.setVfxLayerVisible('vfx_scan_cone', true);
```
